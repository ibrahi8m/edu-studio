import { defineConfig } from 'vitest/config';
export default defineConfig({
  test: { include: ['tests/unit/**/*.test.ts'], environment: 'node', setupFiles: ['fake-indexeddb/auto'] },
});
